package net.diagmed.diagmed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiagmedApplicationTests {

	@Test
	void contextLoads() {
	}

}
