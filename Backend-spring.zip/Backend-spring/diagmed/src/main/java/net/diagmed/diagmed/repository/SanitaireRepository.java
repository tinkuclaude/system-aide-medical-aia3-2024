package net.diagmed.diagmed.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import net.diagmed.diagmed.model.Sanitaire;

public interface SanitaireRepository extends JpaRepository<Sanitaire,Long> {

	public List<Sanitaire> findBynom(String nom);
	
}
