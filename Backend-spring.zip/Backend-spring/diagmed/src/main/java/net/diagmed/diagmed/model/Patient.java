package net.diagmed.diagmed.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "patients")
public class Patient {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
		private long id;
		private String nom;
		private String prenom;
		private String email;
		private String  mdp;
		private String dateNaissance;
		private String lieuNaissance;
	    private String numTel;
	   
	    
	    public Patient() {}
		public Patient(String nom, String prenom, String email, String mdp, String dateNaissance, String numTel) {
			super();
			
			this.nom = nom;
			this.prenom = prenom;
			this.email = email;
			this.mdp = mdp;
			this.dateNaissance = dateNaissance;
			this.numTel = numTel;
		}
		public long getId() {
			return id;
		}
		public String getNom() {
			return nom;
		}
		public void setNom(String nom) {
			this.nom = nom;
		}
		public String getPrenom() {
			return prenom;
		}
		public void setPrenom(String prenom) {
			this.prenom = prenom;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail() {
			this.email = email;
		}
		public String getMdp() {
			return mdp;
		}
		public String getDateNaissance() {
			return dateNaissance;
		}
		public void setDateNaissance(String dateNaissance) {
			this.dateNaissance = dateNaissance;
		}
		
		public String getNumTel() {
			return numTel;
		}
		public void setNumeTel(String numTel) {
			this.numTel = numTel;
		}
		

	
}
