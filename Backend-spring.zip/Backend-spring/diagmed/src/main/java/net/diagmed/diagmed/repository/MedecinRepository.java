package net.diagmed.diagmed.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import net.diagmed.diagmed.model.Medecin;


public interface MedecinRepository extends JpaRepository<Medecin,Long> {
	
	public List<Medecin> findBynom(String nom);

}
