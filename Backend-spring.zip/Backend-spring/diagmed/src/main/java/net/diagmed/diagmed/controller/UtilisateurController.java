package net.diagmed.diagmed.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.diagmed.diagmed.model.Utilisateur;
import net.diagmed.diagmed.repository.UtilisateurRepository;


@RestController
@RequestMapping("/api")


public class UtilisateurController {
	private UtilisateurRepository utilisateurRepository;
	
	@Autowired
	public UtilisateurController(UtilisateurRepository utilisateurRepository) {
		// TODO Auto-generated constructor stub
		this.utilisateurRepository = utilisateurRepository;
	}
	
	@PostMapping("/utilisateurs")
	public ResponseEntity<Utilisateur> createUtilisateur(@RequestBody Utilisateur utilisateur){
		try {
				Utilisateur newUtilisateur = utilisateurRepository.save(new Utilisateur(utilisateur.getNom(),utilisateur.getPrenom(),utilisateur.getEmail(),utilisateur.getMdp())); 
				return new ResponseEntity<>(newUtilisateur, HttpStatus.CREATED);
		} catch(Exception e) {
			
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
								
		}
							
				}
	 @GetMapping("/utilisateurs")
		public ResponseEntity<List<Utilisateur>> getAllUtilisateur(){
			try {
				
				List<Utilisateur> utilisateurList = utilisateurRepository.findAll();
				if(utilisateurList == null || utilisateurList.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				return new ResponseEntity<>(utilisateurList, HttpStatus.OK);
		}catch(Exception e){
				
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		    }
		}
			
}
		
	
	 


