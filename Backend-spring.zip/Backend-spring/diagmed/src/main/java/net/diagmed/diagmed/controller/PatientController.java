package net.diagmed.diagmed.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.diagmed.diagmed.model.Patient;
import net.diagmed.diagmed.repository.PatientRepository;


@RestController
@RequestMapping("/api")

public class PatientController {
	
	
private PatientRepository patientRepository;
	
	@Autowired
	public PatientController(PatientRepository patientRepository) {
		// TODO Auto-generated constructor stub
		this.patientRepository = patientRepository;
	}
	
	@PostMapping("/patients")
	public ResponseEntity<Patient> createPatient(@RequestBody Patient patient){
		try {
				Patient newPatient = patientRepository.save(new Patient(patient.getNom(),patient.getPrenom(),patient.getEmail(),patient.getMdp(),patient.getDateNaissance(),patient.getNumTel())); 
				return new ResponseEntity<>(newPatient, HttpStatus.CREATED);
		} catch(Exception e) {
			
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
								
		}
							
				}
	 @GetMapping("/patients")
		public ResponseEntity<List<Patient>> getAllPatient(){
			try {
				
				List<Patient> patientList = patientRepository.findAll();
				if(patientList == null || patientList.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				return new ResponseEntity<>(patientList, HttpStatus.OK);
		}catch(Exception e){
				
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		    }
		}

}
