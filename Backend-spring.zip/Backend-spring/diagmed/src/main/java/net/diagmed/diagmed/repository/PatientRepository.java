package net.diagmed.diagmed.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import net.diagmed.diagmed.model.Patient;


public interface PatientRepository  extends JpaRepository<Patient,Long>{
	
	public List<Patient> findBynom(String nom);

}
