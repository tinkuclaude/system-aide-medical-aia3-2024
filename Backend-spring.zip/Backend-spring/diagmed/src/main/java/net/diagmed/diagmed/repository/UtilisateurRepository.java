package net.diagmed.diagmed.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import net.diagmed.diagmed.model.Utilisateur;

public interface UtilisateurRepository extends JpaRepository<Utilisateur,Long> {

		public List<Utilisateur> findBynom(String nom);
}
