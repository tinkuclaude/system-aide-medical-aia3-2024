package net.diagmed.diagmed.model;

import javax.persistence.*;

@Entity
@Table(name = "sanitaires")

public class Sanitaire {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String nom;
	private  String type;
	private  String email;
	private  String mdp;
	private  String ville;
	private  String numTel;
	
	public Sanitaire() {}
	
	public Sanitaire(String nom, String type, String email, String mdp, String ville, String numTel ) {
		this.nom = nom;
		this.type = type;
		this.email = email;
		this.mdp = mdp;
		this.ville = ville;
		this.numTel = numTel;
	}

	public Long getId() {
		return id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMdp() {
		return mdp;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public String getNumTel() {
		return numTel;
	}

	public void setNumTel(String numTel) {
		this.numTel = numTel;
	}
	
	  

}
