package net.diagmed.diagmed.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.diagmed.diagmed.model.Medecin;
import net.diagmed.diagmed.repository.MedecinRepository;



@RestController
@RequestMapping("/api")

public class MedecinController {
	
private MedecinRepository medecinRepository;
	
	@Autowired
	public MedecinController(MedecinRepository medecinRepository) {
		// TODO Auto-generated constructor stub
		this.medecinRepository = medecinRepository;
	}
	
	@PostMapping("/medecins")
	public ResponseEntity<Medecin> createMedecin(@RequestBody Medecin medecin){
		try {
				Medecin newMedecin = medecinRepository.save(new Medecin(medecin.getNom(),medecin.getEmail(),medecin.getMdp(),medecin.getNumTel())); 
				return new ResponseEntity<>(newMedecin, HttpStatus.CREATED);
		} catch(Exception e) {
			
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
								
		}
							
				}
	 @GetMapping("/medecins")
		public ResponseEntity<List<Medecin>> getAllMedecin(){
			try {
				
				List<Medecin> medecinList = medecinRepository.findAll();
				if(medecinList == null || medecinList.isEmpty()) {
					return new ResponseEntity<>(HttpStatus.NO_CONTENT);
				}
				return new ResponseEntity<>(medecinList, HttpStatus.OK);
		}catch(Exception e){
				
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		    }
		}


}
